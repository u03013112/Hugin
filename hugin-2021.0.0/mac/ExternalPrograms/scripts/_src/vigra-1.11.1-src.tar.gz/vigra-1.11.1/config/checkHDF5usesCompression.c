#include <H5pubconf.h>

#if !defined(H5_SOMETHING) || !H5_SOMETHING
#error "flag is not defined"
#endif

int main()
{}
