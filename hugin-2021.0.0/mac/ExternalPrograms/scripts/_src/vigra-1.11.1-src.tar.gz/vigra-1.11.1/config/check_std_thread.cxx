#include <thread>
int main() { std::this_thread::yield(); } // https://github.com/ukoethe/vigra/issues/220

