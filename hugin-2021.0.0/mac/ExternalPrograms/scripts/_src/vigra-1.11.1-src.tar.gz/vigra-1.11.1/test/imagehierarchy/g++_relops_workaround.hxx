#if defined(__GNUC__) && (__GNUC__ < 3) && !defined(__SGI_STL_INTERNAL_RELOPS)

#   define __STL_BEGIN_RELOPS_NAMESPACE namespace std { namespace rel_ops {
#   define __STL_END_RELOPS_NAMESPACE }}
#   define __STD_RELOPS std::rel_ops

#include <stl_relops.h>

#   undef __STL_BEGIN_RELOPS_NAMESPACE
#   undef __STL_END_RELOPS_NAMESPACE
#   undef __STD_RELOPS
#endif

